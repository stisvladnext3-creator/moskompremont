<?php
// Скопируйте в config.php. Лучше перенести private за пределы document root
// и задать полный путь через переменную окружения INTERNET_CONFIG.
return [
 'dsn' => 'mysql:host=localhost;dbname=YOUR_DATABASE;charset=utf8mb4',
 'db_user' => 'YOUR_DATABASE_USER',
 'db_password' => 'YOUR_DATABASE_PASSWORD',
 'origin' => 'https://YOUR-DOMAIN.ru', // без завершающего слеша; включая порт при необходимости
 'secure_cookies' => true, // false разрешён только при локальной проверке HTTP
 'admin_user_ids' => [], // ID вашей учётной записи из MySQL, после регистрации и проверки почты вручную
 'qr_image' => '', // например images/payment/ozon-qr.png — ваш QR для приёма платежей
 'recipient' => '', // имя получателя, которое клиент увидит в банке
 'payment_note' => 'После оплаты укажите время перевода и последние 4 цифры телефона отправителя.',
];
