<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
function answer(array $body, int $status = 200): never { http_response_code($status); echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function fail(string $message, int $status = 400): never { answer(['error'=>$message],$status); }
$configPath = getenv('INTERNET_CONFIG') ?: dirname(__DIR__).'/private/config.php';
if (!is_file($configPath)) fail('Кабинет ещё не настроен. Обратитесь к владельцу сайта.',503);
$config = require $configPath;
if (!is_array($config) || empty($config['origin'])) fail('Не настроен адрес сайта.',503);
ini_set('session.use_strict_mode','1'); ini_set('session.use_only_cookies','1'); ini_set('session.gc_maxlifetime','7200');
session_name('internet_account');
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$config['secure_cookies'] ?? true,'httponly'=>true,'samesite'=>'Lax']);
session_start();
if (isset($_SESSION['last_seen']) && time() - $_SESSION['last_seen'] > 7200) { $_SESSION=[]; session_regenerate_id(true); }
$_SESSION['last_seen']=time();
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
$action = $_GET['action'] ?? 'me';
$method = $_SERVER['REQUEST_METHOD'];
$writes=['register','login','logout','create_order','submit_payment','review_order'];
if (in_array($action,$writes,true)) {
 if ($method !== 'POST') fail('Требуется POST.',405);
 if (rtrim($_SERVER['HTTP_ORIGIN'] ?? '', '/') !== rtrim($config['origin'],'/')) fail('Недопустимый источник запроса.',403);
 if (!hash_equals($_SESSION['csrf'], $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) fail('Обновите страницу и попробуйте снова.',403);
 if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) fail('Требуется JSON.',415);
 if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 8192) fail('Слишком большой запрос.',413);
 $raw=file_get_contents('php://input',false,null,0,8193);
 if (strlen($raw)>8192) fail('Слишком большой запрос.',413);
 try { $body=json_decode($raw,true,16,JSON_THROW_ON_ERROR); } catch (Throwable $e) { fail('Некорректный JSON.'); }
 if (!is_array($body)) fail('Некорректные данные.');
} else { if ($method !== 'GET') fail('Метод не поддерживается.',405); $body=[]; }
function field(array $body,string $key,int $max): string {
 $v=$body[$key] ?? '';
 if (!is_string($v) || strlen($v)>$max || preg_match('/[\x00-\x1f]/',$v)) fail('Проверьте поле: '.$key);
 return trim($v);
}
function publicUser(array $u,array $config): array {
 return ['id'=>(int)$u['id'],'first_name'=>$u['first_name'],'last_name'=>$u['last_name'],'telegram'=>$u['telegram'],'email'=>$u['email'],'is_admin'=>in_array((int)$u['id'],array_map('intval',$config['admin_user_ids'] ?? []),true)];
}
function payment(array $config): array {
 $image=$config['qr_image'] ?? '';
 $ready=is_string($image) && preg_match('~^images/payment/[a-zA-Z0-9_.-]+\.(png|jpe?g|webp)$~i',$image) && is_file(dirname(__DIR__).'/'.$image) && !empty($config['recipient']);
 return ['available'=>(bool)$ready,'qr_image'=>$ready?$image:null,'recipient'=>$ready?$config['recipient']:'','note'=>$config['payment_note'] ?? ''];
}
try {
 $db=new PDO($config['dsn'],$config['db_user'],$config['db_password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
 // SQL schema is installed explicitly, never during a request.
 function limitRate(PDO $db,string $scope,int $maximum): void {
  $ip=$_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $bucket=hash('sha256',$scope.'|'.$ip.'|'.intdiv(time(),900));
  $q=$db->prepare('INSERT INTO internet_rate_limits(bucket,attempts,expires_at) VALUES (?,1,?) ON DUPLICATE KEY UPDATE attempts=attempts+1');$q->execute([$bucket,time()+1800]);
  $q=$db->prepare('SELECT attempts FROM internet_rate_limits WHERE bucket=?');$q->execute([$bucket]);
  if ((int)$q->fetchColumn()>$maximum) fail('Слишком много попыток. Повторите через 15 минут.',429);
  if (random_int(1,50)===1) $db->prepare('DELETE FROM internet_rate_limits WHERE expires_at < ?')->execute([time()]);
 }
 $user=null;
 if (isset($_SESSION['user_id'])) { $q=$db->prepare('SELECT id,first_name,last_name,telegram,email FROM internet_users WHERE id=?');$q->execute([$_SESSION['user_id']]);$user=$q->fetch() ?: null; }
 if ($action==='me') answer(['user'=>$user?publicUser($user,$config):null,'csrf'=>$_SESSION['csrf'],'payment'=>payment($config)]);
 if ($action==='register') {
  limitRate($db,'register',10);
  $first=field($body,'first_name',160);$last=field($body,'last_name',160);
  if (!$first || !$last || preg_match_all('/./u',$first)>80 || preg_match_all('/./u',$last)>80) fail('Укажите имя и фамилию (до 80 символов).');
  $email=strtolower(field($body,'email',254));if (!filter_var($email,FILTER_VALIDATE_EMAIL)) fail('Укажите корректную почту.');
  $telegram=field($body,'telegram',100);
  if (!preg_match('~^(?:https://t\.me/|@)([a-zA-Z][a-zA-Z0-9_]{4,31})/?$~',$telegram,$m)) fail('Укажите Telegram: https://t.me/username или @username.');
  $telegram='https://t.me/'.$m[1];
  $password=$body['password'] ?? null;
  if (!is_string($password) || preg_match_all('/./us',$password)<12 || strlen($password)>72) fail('Пароль: не менее 12 символов и не более 72 байт.');
  $hash=password_hash($password,PASSWORD_DEFAULT);
  try { $q=$db->prepare('INSERT INTO internet_users(first_name,last_name,telegram,email,password_hash) VALUES (?,?,?,?,?)');$q->execute([$first,$last,$telegram,$email,$hash]); }
  catch (PDOException $e) { if ($e->getCode()==='23000') fail('Не удалось зарегистрироваться с этими данными. Попробуйте войти.',409);throw $e; }
  session_regenerate_id(true);$_SESSION['user_id']=(int)$db->lastInsertId();$_SESSION['csrf']=bin2hex(random_bytes(32));
  answer(['user'=>publicUser(['id'=>$_SESSION['user_id'],'first_name'=>$first,'last_name'=>$last,'telegram'=>$telegram,'email'=>$email],$config),'csrf'=>$_SESSION['csrf']],201);
 }
 if ($action==='login') {
  limitRate($db,'login',25);
  $email=strtolower(field($body,'email',254));$password=$body['password'] ?? '';
  if (!is_string($password) || strlen($password)>72) fail('Неверная почта или пароль.',401);
  $q=$db->prepare('SELECT * FROM internet_users WHERE email=?');$q->execute([$email]);$found=$q->fetch();
  $dummy='$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi';
  $valid=password_verify($password,$found['password_hash'] ?? $dummy);
  if (!$found || !$valid) fail('Неверная почта или пароль.',401);
  if (password_needs_rehash($found['password_hash'],PASSWORD_DEFAULT)) $db->prepare('UPDATE internet_users SET password_hash=? WHERE id=?')->execute([password_hash($password,PASSWORD_DEFAULT),$found['id']]);
  session_regenerate_id(true);$_SESSION['user_id']=(int)$found['id'];$_SESSION['csrf']=bin2hex(random_bytes(32));answer(['user'=>publicUser($found,$config),'csrf'=>$_SESSION['csrf']]);
 }
 if ($action==='logout') { $_SESSION=[];session_regenerate_id(true);$_SESSION['csrf']=bin2hex(random_bytes(32));answer(['ok'=>true,'csrf'=>$_SESSION['csrf']]); }
 if (!$user) fail('Сначала войдите в кабинет.',401);
 $admin=publicUser($user,$config)['is_admin'];
 if ($action==='orders') {
  $q=$db->prepare('SELECT id,plan,devices,amount,status,payment_reference,created_at,submitted_at,reviewed_at FROM internet_orders WHERE user_id=? ORDER BY created_at DESC LIMIT 100');$q->execute([$user['id']]);answer(['orders'=>$q->fetchAll()]);
 }
 if ($action==='create_order') {
  limitRate($db,'orders',30);
  if (!payment($config)['available']) fail('Владелец ещё не добавил реквизиты оплаты.',503);
  $plan=field($body,'plan',20);$devices=$body['devices'] ?? null;
  if (!in_array($plan,['monthly','lifetime'],true) || !is_int($devices) || $devices<1 || $devices>20) fail('Выберите тариф и от 1 до 20 устройств.');
  $rates=$plan==='monthly'?[1=>250,2=>225,3=>200,4=>175]:[1=>3000,2=>2500,3=>2000,4=>1650];
  $amount=$rates[min($devices,4)]*$devices;
  $db->beginTransaction();$lock=$db->prepare('SELECT id FROM internet_users WHERE id=? FOR UPDATE');$lock->execute([$user['id']]);
  $q=$db->prepare("SELECT id FROM internet_orders WHERE user_id=? AND status IN ('created','submitted') LIMIT 1");$q->execute([$user['id']]);if ($q->fetch()) { $db->rollBack(); fail('У вас уже есть незавершённая заявка. Откройте её в списке.',409); }
  $id=bin2hex(random_bytes(16));$db->prepare('INSERT INTO internet_orders(id,user_id,plan,devices,amount) VALUES (?,?,?,?,?)')->execute([$id,$user['id'],$plan,$devices,$amount]);$db->commit();answer(['id'=>$id,'amount'=>$amount],201);
 }
 if ($action==='submit_payment') {
  $id=field($body,'id',32);$reference=field($body,'reference',500);if (strlen($reference)<5) fail('Укажите время перевода и данные для сверки.');
  $q=$db->prepare("UPDATE internet_orders SET status='submitted',payment_reference=?,submitted_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=? AND status='created'");$q->execute([$reference,$id,$user['id']]);if (!$q->rowCount()) fail('Заявка не найдена или уже отправлена.',409);answer(['ok'=>true]);
 }
 if ($action==='admin_orders') {
  if (!$admin) fail('Нет доступа.',403);
  $q=$db->query("SELECT o.*,u.first_name,u.last_name,u.email,u.telegram FROM internet_orders o JOIN internet_users u ON u.id=o.user_id ORDER BY o.created_at DESC LIMIT 200");answer(['orders'=>$q->fetchAll()]);
 }
 if ($action==='review_order') {
  if (!$admin) fail('Нет доступа.',403);
  $id=field($body,'id',32);$status=field($body,'status',20);if (!in_array($status,['paid','rejected'],true)) fail('Недопустимый статус.');
  $q=$db->prepare("UPDATE internet_orders SET status=?,reviewed_at=CURRENT_TIMESTAMP,reviewed_by=? WHERE id=? AND status='submitted'");$q->execute([$status,$user['id'],$id]);if (!$q->rowCount()) fail('Заявка уже обработана или не отправлена на проверку.',409);answer(['ok'=>true]);
 }
 fail('Действие не найдено.',404);
} catch (Throwable $e) { error_log('Internet account: '.$e->getMessage()); fail('Сервис временно недоступен. Попробуйте позже.',503); }
