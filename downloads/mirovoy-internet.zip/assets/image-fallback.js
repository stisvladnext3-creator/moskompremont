// На действующем сайте используются оригинальные PNG из папки images.
// В автономной копии логотип заменяется favicon того же сайта.
document.addEventListener('error', event => {
  const image = event.target;
  if (!(image instanceof HTMLImageElement)) return;
  if (image.dataset.fallback) {
    const fallback = image.dataset.fallback;
    delete image.dataset.fallback;
    image.src = fallback;
  } else if (image.hasAttribute('data-optional-image')) {
    image.hidden = true;
  }
}, true);
