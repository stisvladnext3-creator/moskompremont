// Заполните реальными данными. Секреты и ключи доступа сюда не добавляйте.
window.SITE_CONFIG = {
  // Необязательный API на том же домене. Формат: { "links": ["https://…", …] }.
  // Ответ должен содержать ровно 10 ссылок. Не храните закрытый ключ API в браузере.
  subscriptionEndpoint: '',
  subscriptionLinks: [],
  // Пример: { name: 'Название', location: 'Расположение', description: 'Описание', subscriptionIndex: 0 }
  // subscriptionIndex — необязательный номер ссылки в массиве (от 0 до 9).
  servers: [],
  // Пример: { title: 'На телефоне', text: 'Пошаговая инструкция…' }
  instructions: [],
  // Международный формат, например +7…, без пробелов.
  // Контакты взяты из присланной главной страницы сайта.
  phone: '+79152449644',
  phoneLabel: '+7 (915) 244-96-44',
  telegramUrl: 'https://t.me/Alex_RemPC',
  whatsappUrl: 'https://wa.me/79152449644',
  maxUrl: 'https://max.ru/u/f9LHodD0cOLayzO1liLeiwV-6FMK18nE5HQfyTbhUjJvlooXPnnrPQO5jfE'
};
