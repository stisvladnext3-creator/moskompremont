package com.v2ray.ang.ui.main

import android.content.Intent
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.v2.createEmptyComposeRule
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.lifecycle.ViewModelProvider
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import androidx.test.uiautomator.Until
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.dto.entities.SubscriptionItem
import com.v2ray.ang.handler.moskom.MoskomPolicy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.io.File
import java.net.URL

/** Exercises the real Compose shell, encrypted account session and native daemon on Android. */
class MoskomIntegrationTest {
    @get:Rule val compose = createEmptyComposeRule()
    private lateinit var scenario: ActivityScenario<MainActivity>
    private lateinit var model: MainViewModel
    private val context get()=InstrumentationRegistry.getInstrumentation().targetContext
    private val device get()=UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())
    private fun waitReady(){compose.waitForIdle();compose.waitUntil(120_000){model.moskom().state.value.let{it.loaded&&!it.busy&&!it.connecting}};compose.waitForIdle()}
    private fun dispatch(action:MoskomAction){waitReady();compose.runOnIdle{model.onAction(MainAction.Moskom(action))};waitReady()}
    private fun phase(value:Int){URL("http://10.0.2.2:18080/fixture/phase?value=$value").openStream().close()}
    private fun click(tag:String){val node=compose.onNodeWithTag(tag);if(tag=="moskom_save_choices"||tag=="moskom_choices_close")node.performClick()else node.performScrollTo().performClick()}
    private fun text(id:Int)=context.getString(id)
    private fun closeSheet(){
        if(compose.onAllNodesWithTag("moskom_choices_close").fetchSemanticsNodes(atLeastOneRootRequired=false).isNotEmpty())click("moskom_choices_close")
        else compose.onNodeWithText(text(R.string.moskom_close)).performScrollTo().performClick()
    }
    private fun searchChoices(value:String){
        compose.onNodeWithTag("moskom_choice_search").performClick().performTextReplacement(value)
        compose.waitUntil(30_000){model.moskom().state.value.choiceFilter.query==value};compose.waitForIdle()
    }
    private fun choice(id:String):SemanticsNodeInteraction {
        compose.onNodeWithTag("moskom_choices_list").performScrollToNode(hasTestTag("moskom_choice_$id"))
        return compose.onNodeWithTag("moskom_choice_$id")
    }
    private fun screenshot(name:String){
        compose.waitForIdle()
        val file=File(context.cacheDir,"$name.png");device.takeScreenshot(file)
        val connection=URL("http://10.0.2.2:18080/fixture/screenshot?name=$name.png").openConnection() as java.net.HttpURLConnection
        connection.requestMethod="POST";connection.doOutput=true
        connection.outputStream.use{out->file.inputStream().use{it.copyTo(out)}}
        connection.inputStream.close();connection.disconnect();file.delete()
    }
    private fun approveSystemDialog(){
        val allow=device.wait(Until.findObject(By.res("android:id/button1")),15_000)
        assertNotNull("Android VPN consent must be visible",allow)
        allow!!.click()
        assertTrue("Android VPN consent must close after approval",device.wait(Until.gone(By.pkg("com.android.vpndialogs")),15_000))
    }
    private fun assertVpnUid(packageName:String,included:Boolean) {
        val listing=device.executeShellCommand("cmd package list packages -U $packageName")
        val uid=Regex("package:"+Regex.escape(packageName)+"\\s+uid:(\\d+)").find(listing)?.groupValues?.get(1)?.toInt()
        assertNotNull("Missing installed fixture UID: $listing",uid)
        val networks=device.executeShellCommand("dumpsys connectivity").substringAfter("Current Networks:").substringBefore("Network Requests:")
        val vpn=networks.lineSequence().firstOrNull{Regex("InterfaceName:\\s*tun[0-9]+").containsMatchIn(it)}
        assertNotNull("Missing actual VPN network: $networks",vpn)
        val field=Regex("\\bUids:\\s*<([^>]+)>").find(vpn!!)?.groupValues?.get(1)
        assertNotNull("VPN must publish its real UID ranges: $vpn",field)
        val ranges=Regex("(\\d+)(?:-(\\d+))?").findAll(field!!).map{match->
            val first=match.groupValues[1].toInt();first..(match.groupValues[2].toIntOrNull()?:first)
        }.toList()
        assertEquals("VPN UID policy for $packageName ($uid): $vpn",included,ranges.any{uid!! in it})
    }

    private fun assertDomesticDnsAndRoutes() {
        runBlocking(Dispatchers.IO) {
            val result=com.v2ray.ang.core.CoreConfigManager.getV2rayConfig(context,MmkvManager.getSelectServer().orEmpty())
            assertTrue(result.errorMessage,result.status)
            val json=com.google.gson.JsonParser.parseString(result.content).asJsonObject
            val rules=json.getAsJsonObject("routing").getAsJsonArray("rules").map{it.asJsonObject}
            fun hasDomain(rule:com.google.gson.JsonObject,suffix:String)=rule.getAsJsonArray("domain")?.any{it.asString.endsWith(suffix)}==true
            val direct=rules.indexOfFirst{it.get("outboundTag")?.asString=="direct"&&hasDomain(it,"whoosh.bike")}
            val proxy=rules.indexOfFirst{it.get("outboundTag")?.asString=="proxy"&&hasDomain(it,":ru-blocked")}
            assertTrue("Domestic rule must precede blocked geosites",direct>=0&&proxy>direct)
            assertTrue(rules.none{it.get("outboundTag")?.asString=="block"&&hasDomain(it,":category-ads-all")})
            val servers=json.getAsJsonObject("dns").getAsJsonArray("servers").filter{it.isJsonObject}.map{it.asJsonObject}
            val domestic=servers.firstOrNull{server->server.getAsJsonArray("domains")?.any{it.asString.endsWith("whoosh.bike")}==true}
            assertNotNull("Domestic apps need their direct DNS domain policy",domestic)
            val tag=domestic!!.get("tag").asString
            assertTrue("Domestic DNS must leave through the direct outbound",rules.any{it.get("outboundTag")?.asString=="direct"&&it.getAsJsonArray("inboundTag")?.any{entry->entry.asString==tag}==true})
        }
    }
    @Test fun accountGroupsRoutingDnsNativeLifecycleAndRevocation() {
        phase(0)
        device.executeShellCommand("pm grant ru.moskompremont.vpn android.permission.POST_NOTIFICATIONS")
        scenario=ActivityScenario.launch(Intent(context,MainActivity::class.java).putExtra("moskom_fixture","http://10.0.2.2:18080/").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        scenario.onActivity{model=ViewModelProvider(it)[MainViewModel::class.java]}
        compose.mainClock.advanceTimeByFrame()
        waitReady()
        compose.waitUntil(30_000){compose.onAllNodesWithTag("moskom_power").fetchSemanticsNodes(atLeastOneRootRequired=false).isNotEmpty()}
        scenario.onActivity{assertFalse("Dark shell must use readable light system bar icons",androidx.core.view.WindowCompat.getInsetsController(it.window,it.window.decorView).isAppearanceLightStatusBars)}
        assertTrue(model.moskom().state.value.groups.isEmpty())
        compose.onNodeWithTag("moskom_power").assertIsNotEnabled()
        screenshot("01-empty")
        // Touch UI login with the IME open, including the last form action.
        click("moskom_account")
        compose.onNodeWithTag("moskom_email").performScrollTo().performTextInput("client@example.test")
        compose.onNodeWithTag("moskom_password").performScrollTo().performTextInput("fixture-pass")
        compose.onNodeWithTag("moskom_login_submit").performScrollTo().performClick()
        waitReady();compose.waitUntil(30_000){model.moskom().state.value.user!=null}
        closeSheet()
        val groups=model.moskom().state.value.groups
        assertEquals(setOf("VPN-A","VPN-B"),groups.map{it.name}.toSet())
        assertEquals(listOf("A-1","A-2"),groups.first{it.name=="VPN-A"}.servers.map{it.name})
        dispatch(MoskomAction.Group("moskom-cabinet-41-801"))
        compose.onNodeWithTag("moskom_subscription_duration").assertTextEquals("Бессрочная подписка")
        screenshot("02-account")
        click("moskom_subscription");compose.onNodeWithText("VPN-B · 1").performClick();waitReady()
        assertEquals("moskom-cabinet-41-802",model.moskom().state.value.group)
        compose.onNodeWithTag("moskom_subscription_duration").assertTextContains("Осталось: 25 дн.",substring=true)
        compose.onNodeWithTag("moskom_subscription_expires").assertTextContains("(МСК)",substring=true)
        URL("http://10.0.2.2:18080/fixture/term?days=55").openStream().close()
        dispatch(MoskomAction.Sync)
        compose.onNodeWithTag("moskom_subscription_duration").assertTextContains("Осталось: 55 дн.",substring=true)
        screenshot("02-subscription-term")
        click("moskom_server");compose.onNodeWithText("A-1").assertDoesNotExist();compose.onAllNodesWithText("B-1").onLast().performClick();waitReady()
        click("moskom_routing");compose.onNodeWithText(text(R.string.moskom_mode_except)).performClick();waitReady()
        assertEquals("except_ru",model.moskom().state.value.mode)
        // Menu, DNS dialog, persistence and recreation by domain ID.
        click("moskom_menu");compose.onNodeWithText(text(R.string.moskom_dns)).performClick()
        compose.onNodeWithText(text(R.string.moskom_dns_auto)).performClick();compose.onNodeWithText(text(R.string.moskom_dns_google)).performClick()
        compose.onNodeWithText(text(R.string.moskom_save_dns)).performScrollTo().performClick();waitReady();closeSheet()
        assertEquals("google",model.moskom().state.value.dns)
        dispatch(MoskomAction.Rules)
        assertEquals(0,model.moskom().state.value.error)
        assertEquals("google",model.moskom().state.value.dns)
        assertEquals("except_ru",model.moskom().state.value.mode)
        val selected=model.moskom().state.value.server
        scenario.recreate();scenario.onActivity{model=ViewModelProvider(it)[MainViewModel::class.java]};waitReady()
        assertEquals(selected,model.moskom().state.value.server);assertEquals("google",model.moskom().state.value.dns)
        assertEquals("moskom-cabinet-41-802",model.moskom().state.value.group)
        compose.onNodeWithTag("moskom_subscription_duration").assertTextContains("Осталось: 55 дн.",substring=true)
        // Real menu, merged checkbox semantics, keyboard and stable-ID persistence.
        click("moskom_menu");compose.onNodeWithText(text(R.string.moskom_services)).performClick()
        compose.waitUntil(30_000){!model.moskom().state.value.choiceLoading}
        assertEquals(27,model.moskom().state.value.services.size)
        compose.onNodeWithTag("moskom_choices_list").performScrollToNode(hasTestTag("moskom_custom_domains"))
        compose.onNodeWithTag("moskom_custom_domains").performTextInput("bad*.example")
        waitReady();click("moskom_save_choices");waitReady()
        assertEquals(R.string.moskom_custom_domains_invalid,model.moskom().state.value.customDomainsError)
        assertTrue(MmkvManager.decodeSettingsStringSet("moskom_custom_domains").orEmpty().isEmpty())
        compose.onNodeWithTag("moskom_custom_domains").performTextClearance()
        compose.onNodeWithTag("moskom_custom_domains").performTextInput("custom.fixture, full:only.fixture")
        compose.onNodeWithTag("moskom_save_choices").assertIsDisplayed()

        searchChoices("YOUTUBE");choice("youtube").performClick().assertIsOn()
        searchChoices("  mEEt  ");val meet=choice("google-meet")
        meet.assertIsOff().performClick();meet.assertIsOn()
        device.pressDPadDown();compose.waitForIdle() // Enter hardware-keyboard input mode before requesting checkbox focus.
        for(key in listOf(Key.Enter,Key.Spacebar,Key.DirectionCenter)) {
            meet.performSemanticsAction(SemanticsActions.RequestFocus){it()}
            meet.assertIsFocused().performKeyInput{pressKey(key)}
            compose.waitForIdle()
        }
        meet.assertIsOff().assertIsEnabled().performClick();meet.assertIsOn()
        searchChoices("")
        compose.onNodeWithTag("moskom_save_choices").assertIsDisplayed()
        compose.onNodeWithTag("moskom_choices_list").performScrollToIndex(27)
        compose.onNodeWithTag("moskom_save_choices").assertIsDisplayed()
        searchChoices("missing-search-fixture")
        compose.onNodeWithText(text(R.string.moskom_search_empty)).assertExists()
        assertEquals(setOf("youtube","google-meet"),model.moskom().state.value.chosenServices)
        scenario.recreate();scenario.onActivity{model=ViewModelProvider(it)[MainViewModel::class.java]};waitReady()
        compose.onNodeWithTag("moskom_choice_search").assertTextContains("missing-search-fixture")
        searchChoices("meet");choice("google-meet").assertIsOn()
        compose.onNodeWithTag("moskom_choice_search").performClick();compose.waitForIdle()
        compose.waitUntil(15_000){device.executeShellCommand("dumpsys input_method").contains("mInputShown=true")}
        compose.onNodeWithTag("moskom_save_choices").assertIsDisplayed();screenshot("09-search-pinned")
        waitReady();click("moskom_save_choices");waitReady();screenshot("08-services");closeSheet()
        dispatch(MoskomAction.Mode("services"));assertTrue(model.moskom().state.value.selectionReady)
        assertFalse(MmkvManager.decodeSettingsBool(AppConfig.PREF_PER_APP_PROXY))
        assertEquals(setOf("youtube","google-meet"),model.moskom().state.value.chosenServices)
        scenario.recreate();scenario.onActivity{model=ViewModelProvider(it)[MainViewModel::class.java]};waitReady()
        assertEquals("services",model.moskom().state.value.mode);assertEquals(setOf("youtube","google-meet"),model.moskom().state.value.chosenServices)
        assertEquals(setOf("domain:custom.fixture","full:only.fixture"),MmkvManager.decodeSettingsStringSet("moskom_custom_domains"))
        assertTrue(model.moskom().state.value.customDomainsText.contains("custom.fixture"))

        dispatch(MoskomAction.Mode("apps"));assertFalse(model.moskom().state.value.selectionReady)
        compose.onNodeWithTag("moskom_power").assertIsNotEnabled()
        click("moskom_menu");compose.onNodeWithText(text(R.string.moskom_apps)).performClick()
        compose.waitUntil(30_000){!model.moskom().state.value.choiceLoading}
        assertTrue(model.moskom().state.value.installedApps.any{it.id=="com.android.settings"})
        searchChoices("COM.ANDROID.SETTINGS");val settingsApp=choice("com.android.settings")
        settingsApp.assertIsOff().performClick();settingsApp.assertIsOn()
        searchChoices("no-such-installed-app");compose.onNodeWithText(text(R.string.moskom_search_empty)).assertExists()
        compose.onNodeWithTag("moskom_save_choices").assertIsDisplayed()
        waitReady();click("moskom_save_choices");waitReady();closeSheet()
        assertTrue(model.moskom().state.value.selectionReady)
        assertEquals(setOf("com.android.settings"),MmkvManager.decodeSettingsStringSet(AppConfig.PREF_PER_APP_PROXY_SET))
        assertTrue(MmkvManager.decodeSettingsBool(AppConfig.PREF_PER_APP_PROXY))
        assertFalse(MmkvManager.decodeSettingsBool(AppConfig.PREF_BYPASS_APPS))
        dispatch(MoskomAction.Mode("except_ru"))
        assertFalse(MmkvManager.decodeSettingsBool(AppConfig.PREF_PER_APP_PROXY))
        // Native real-ping works while VPN is off and must traverse the host Xray inbound.
        runBlocking(Dispatchers.IO){MmkvManager.encodeSettings(AppConfig.PREF_DELAY_TEST_URL,"http://127.0.0.1:18080/ping")}
        click("moskom_availability")
        compose.waitUntil(60_000){model.serversForGroup(model.moskom().state.value.group).value.firstOrNull{it.guid==selected}?.testDelayMillis?.let{it>0}==true}
        compose.waitUntil(30_000){!model.uiState.value.isTesting}
        waitReady()
        screenshot("03-real-availability")
        // Real Android permission flow and daemon IPC running/stopped state, repeated.
        compose.onNodeWithTag("moskom_power").assertIsEnabled()
        click("moskom_power");approveSystemDialog()
        compose.waitUntil(60_000){model.uiState.value.isRunning};screenshot("04-connected")
        click("moskom_power");compose.waitUntil(30_000){!model.uiState.value.isRunning}
        // Android-owned restart must fail cleanly for empty/uninstalled app selections.
        for(packages in listOf(emptySet<String>(),setOf("ru.moskompremont.fixture.removed"))) {
            runBlocking(Dispatchers.IO){MmkvManager.encodeSettings(AppConfig.PREF_PER_APP_PROXY_SET,packages.toMutableSet())}
            dispatch(MoskomAction.Mode("apps"));assertFalse(model.moskom().state.value.selectionReady)
            val intent=Intent(android.net.VpnService.SERVICE_INTERFACE).setClassName(context,"com.v2ray.ang.service.CoreVpnService")
            androidx.core.content.ContextCompat.startForegroundService(context,intent)
            Thread.sleep(1000)
            compose.waitUntil(30_000){!device.executeShellCommand("dumpsys activity services ru.moskompremont.vpn").contains("com.v2ray.ang.service.CoreVpnService")}
            assertFalse(model.uiState.value.isRunning)
        }
        runBlocking(Dispatchers.IO){MmkvManager.encodeSettings(AppConfig.PREF_PER_APP_PROXY_SET,mutableSetOf("com.android.settings"))}
        dispatch(MoskomAction.Mode("apps"))
        val systemIntent=Intent(android.net.VpnService.SERVICE_INTERFACE).setClassName(context,"com.v2ray.ang.service.CoreVpnService")
        val readyFile=File(context.filesDir,"moskom-vpn-preflight-ready");readyFile.delete()
        androidx.core.content.ContextCompat.startForegroundService(context,Intent(systemIntent).putExtra("moskom_fixture_setup_delay",2000L))
        compose.waitUntil(15_000){readyFile.exists()}
        context.stopService(systemIntent)
        compose.waitUntil(30_000){!device.executeShellCommand("dumpsys activity services ru.moskompremont.vpn").contains("com.v2ray.ang.service.CoreVpnService")}
        Thread.sleep(2200);assertFalse(model.uiState.value.isRunning)
        androidx.core.content.ContextCompat.startForegroundService(context,Intent(systemIntent).putExtra("moskom_fixture_fail_after_tun",true))
        Thread.sleep(1000)
        compose.waitUntil(30_000){!device.executeShellCommand("dumpsys activity services ru.moskompremont.vpn").contains("com.v2ray.ang.service.CoreVpnService")}
        assertFalse(model.uiState.value.isRunning)
        dispatch(MoskomAction.Mode("except_ru"))
        // Both new policies must also start and tear down the real Android VPN daemon.
        dispatch(MoskomAction.Mode("apps"));click("moskom_power");compose.waitUntil(60_000){model.uiState.value.isRunning}
        repeat(2){androidx.core.content.ContextCompat.startForegroundService(context,systemIntent)}
        Thread.sleep(500);assertTrue(model.uiState.value.isRunning)
        val connectivity=device.executeShellCommand("dumpsys connectivity")
        assertTrue(connectivity,connectivity.contains("Current Networks:"))
        val currentNetworks=connectivity.substringAfter("Current Networks:").substringBefore("Network Requests:")
        val tunnels=Regex("InterfaceName:\\s*(tun[0-9]+)").findAll(currentNetworks).map{it.groupValues[1]}.toSet()
        assertEquals(currentNetworks,1,tunnels.size)
        click("moskom_power");compose.waitUntil(30_000){!model.uiState.value.isRunning}
        dispatch(MoskomAction.Mode("services"))
        dispatch(MoskomAction.ServiceChoice("telegram",true));dispatch(MoskomAction.ServiceChoice("whatsapp",true));dispatch(MoskomAction.SaveChoices)
        runBlocking(Dispatchers.IO) {
            val result=com.v2ray.ang.core.CoreConfigManager.getV2rayConfig(context,MmkvManager.getSelectServer().orEmpty());assertTrue(result.errorMessage,result.status)
            val config=com.google.gson.JsonParser.parseString(result.content).asJsonObject
            assertTrue(config.getAsJsonArray("inbounds").map{it.asJsonObject}.filter{it.has("sniffing")}.any{it.getAsJsonObject("sniffing").get("routeOnly")?.asBoolean==true})
            val servers=config.getAsJsonObject("dns").getAsJsonArray("servers")
            assertTrue("No catch-all proxy DNS in selected-services mode",servers.none{it.isJsonPrimitive})
            val fallback=servers.map{it.asJsonObject}.filter{it.get("tag")?.asString?.startsWith("moskom-direct-fallback-")==true}
            assertTrue("Expected direct DNS fallback for ordinary sites",fallback.isNotEmpty())
            val tags=fallback.map{it.get("tag").asString}.toSet()
            assertTrue(config.getAsJsonObject("routing").getAsJsonArray("rules").map{it.asJsonObject}.any{rule->rule.get("outboundTag")?.asString=="direct"&&rule.getAsJsonArray("inboundTag")?.any{it.asString in tags}==true})
        }
        click("moskom_power");compose.waitUntil(60_000){model.uiState.value.isRunning}
        for(ip in listOf("91.105.192.8","57.144.0.8")) {
            val script=File(requireNotNull(context.getExternalFilesDir(null)),"media-probe.sh")
            runBlocking(Dispatchers.IO){script.writeText("#!/system/bin/sh\nprintf 'GET /media HTTP/1.1\\r\\nHost: media.fixture.invalid\\r\\nConnection: close\\r\\n\\r\\n' | toybox nc -w 5 $ip 18839\n")}
            var media=""
            // UiAutomation executes argv directly; a script file preserves the pipe.
            // Native running IPC can also precede HEV's first packet by a few ticks.
            repeat(3){if(!media.contains("moskom-media-fixture")){Thread.sleep(500);media=device.executeShellCommand("sh "+script.absolutePath)}}
            assertTrue("Messenger media failed through native Android VPN: $ip, bytes=${media.length}, response=${media.take(200)}",media.contains("moskom-media-fixture")&&media.length>60_000)
            script.delete()
        }
        click("moskom_power");compose.waitUntil(30_000){!model.uiState.value.isRunning}
        // Test production bank/transport UID exclusions with installed code-free
        // package fixtures; no real bank app, account or third-party APK is used.
        dispatch(MoskomAction.Mode("blocked"));assertDomesticDnsAndRoutes()
        readyFile.delete()
        androidx.core.content.ContextCompat.startForegroundService(context,Intent(systemIntent).putExtra("moskom_fixture_setup_delay",2000L))
        compose.waitUntil(15_000){readyFile.exists()};context.stopService(systemIntent)
        compose.waitUntil(30_000){!device.executeShellCommand("dumpsys activity services ru.moskompremont.vpn").contains("com.v2ray.ang.service.CoreVpnService")}
        Thread.sleep(2200);assertFalse(model.uiState.value.isRunning)
        androidx.core.content.ContextCompat.startForegroundService(context,Intent(systemIntent).putExtra("moskom_fixture_fail_after_tun",true))
        Thread.sleep(1000)
        compose.waitUntil(30_000){!device.executeShellCommand("dumpsys activity services ru.moskompremont.vpn").contains("com.v2ray.ang.service.CoreVpnService")}
        assertFalse(model.uiState.value.isRunning)
        click("moskom_power");compose.waitUntil(60_000){model.uiState.value.isRunning}
        for(id in listOf("com.punicapp.whoosh","ru.yandex.yandexmaps","com.sberbankmobile"))assertVpnUid(id,false)
        assertVpnUid("com.android.settings",true)
        repeat(2){androidx.core.content.ContextCompat.startForegroundService(context,systemIntent)}
        Thread.sleep(500);assertTrue(model.uiState.value.isRunning);assertVpnUid("com.punicapp.whoosh",false)
        click("moskom_power");compose.waitUntil(30_000){!model.uiState.value.isRunning};context.stopService(systemIntent)
        dispatch(MoskomAction.Mode("all"));click("moskom_power");compose.waitUntil(60_000){model.uiState.value.isRunning}
        assertVpnUid("com.punicapp.whoosh",true)
        click("moskom_power");compose.waitUntil(30_000){!model.uiState.value.isRunning}
        dispatch(MoskomAction.Mode("except_ru"));click("moskom_power");compose.waitUntil(60_000){model.uiState.value.isRunning}
        // The deletion handler rejects account subscriptions before stopping VPN.
        val protectedGroup=model.moskom().state.value.group
        dispatch(MoskomAction.DeleteSubscription(protectedGroup))
        assertEquals(R.string.moskom_subscription_not_removable,model.moskom().state.value.error)
        assertTrue(model.uiState.value.isRunning)
        assertEquals(protectedGroup,model.moskom().state.value.group)
        click("moskom_menu");compose.onNodeWithText(text(R.string.moskom_manage_subscriptions)).performClick()
        compose.onNodeWithTag("moskom_manual_subscriptions_empty").assertExists()
        compose.onNodeWithTag("moskom_delete_subscription_$protectedGroup").assertDoesNotExist();closeSheet()
        // Revocation stops the selected B group before it is removed; A's changed URL is imported.
        phase(1);dispatch(MoskomAction.Sync)
        assertFalse(model.uiState.value.isRunning)
        assertEquals(listOf("VPN-A"),model.moskom().state.value.groups.map{it.name})
        assertEquals(listOf("A-NEW-1","A-NEW-2"),model.moskom().state.value.groups.single().servers.map{it.name})
        // A transient download failure preserves the previous working group.
        phase(3);dispatch(MoskomAction.Sync)
        assertEquals(listOf("A-NEW-1","A-NEW-2"),model.moskom().state.value.groups.first{it.name=="VPN-A"}.servers.map{it.name})
        assertEquals(R.string.moskom_partial_sync,model.moskom().state.value.message)
        dispatch(MoskomAction.Import("vless://33333333-3333-4333-8333-333333333333@10.0.2.2:18081?encryption=none&security=none&type=tcp#Manual-key"))
        assertTrue(model.moskom().state.value.groups.any{it.id==AppConfig.DEFAULT_SUBSCRIPTION_ID})
        dispatch(MoskomAction.Logout)
        assertNull(model.moskom().state.value.user)
        assertTrue(model.moskom().state.value.groups.none{it.id.startsWith(MoskomPolicy.CABINET)})
        assertEquals("Manual-key",model.moskom().state.value.groups.single().servers.single().name)
        // Help stays inside the branded activity and includes the owner's routing descriptions.
        click("moskom_help")
        compose.onNodeWithText("Режим «Всё» — полная маршрутизация",substring=true).assertExists();screenshot("05-help");closeSheet()
        // Standard focus activation must match touch for keyboard and D-pad users.
        for(key in listOf(Key.Enter,Key.Spacebar,Key.DirectionCenter)) {
            // Real hardware navigation leaves Android touch mode before a button requests focus.
            device.pressDPadDown();compose.waitForIdle()
            compose.onNodeWithTag("moskom_help").performScrollTo().performSemanticsAction(SemanticsActions.RequestFocus){it()}
            compose.onNodeWithTag("moskom_help").assertIsFocused().performKeyInput{pressKey(key)}
            compose.onNodeWithText("Режим «Всё» — полная маршрутизация",substring=true).assertExists();closeSheet()
        }
        compose.onNodeWithTag("moskom_menu").assertContentDescriptionEquals(text(R.string.moskom_menu))
        compose.onNodeWithTag("moskom_add").assertContentDescriptionEquals(text(R.string.moskom_add))
        screenshot("06-manual-after-logout")
        // Management is available from the real menu. Standalone keys and account
        // subscriptions do not appear among manually imported subscriptions.
        click("moskom_menu");compose.onNodeWithText(text(R.string.moskom_manage_subscriptions)).performClick()
        compose.onNodeWithTag("moskom_manual_subscriptions_empty").assertExists();closeSheet()
        phase(0)
        dispatch(MoskomAction.Import("http://10.0.2.2:18080/sub/a"))
        val manualA=model.moskom().state.value.group
        val aServers=model.moskom().state.value.groups.first{it.id==manualA}.servers.map{it.id}
        dispatch(MoskomAction.Import("http://10.0.2.2:18080/sub/b"))
        val manualB=model.moskom().state.value.group
        val bServers=model.moskom().state.value.groups.first{it.id==manualB}.servers.map{it.id}
        assertEquals(setOf(manualA,manualB),model.moskom().state.value.manualSubscriptions.map{it.id}.toSet())
        dispatch(MoskomAction.Group(manualA));click("moskom_power")
        compose.waitUntil(60_000){model.uiState.value.isRunning}
        click("moskom_menu");compose.onNodeWithText(text(R.string.moskom_manage_subscriptions)).performClick()
        click("moskom_delete_subscription_$manualB")
        compose.onNodeWithTag("moskom_confirm_subscription_delete").assertExists()
        click("moskom_cancel_subscription_delete")
        assertTrue(model.moskom().state.value.groups.any{it.id==manualB})
        // Keyboard/D-pad activation reaches the same confirmation and cancellation.
        for(key in listOf(Key.Enter,Key.DirectionCenter)) {
            device.pressDPadDown();compose.waitForIdle()
            compose.onNodeWithTag("moskom_delete_subscription_$manualB").performScrollTo().performSemanticsAction(SemanticsActions.RequestFocus){it()}
            compose.onNodeWithTag("moskom_delete_subscription_$manualB").assertIsFocused().performKeyInput{pressKey(key)}
            click("moskom_cancel_subscription_delete")
        }
        click("moskom_delete_subscription_$manualB");click("moskom_confirm_subscription_delete");waitReady()
        assertTrue("Deleting an inactive group must keep VPN running",model.uiState.value.isRunning)
        assertEquals(manualA,model.moskom().state.value.group)
        assertTrue(model.moskom().state.value.groups.none{it.id==manualB})
        runBlocking(Dispatchers.IO){assertNull(MmkvManager.decodeSubscription(manualB));bServers.forEach{assertNull(MmkvManager.decodeServerConfig(it))}}
        closeSheet();click("moskom_menu");compose.onNodeWithText(text(R.string.moskom_manage_subscriptions)).performClick()
        compose.onNodeWithTag("moskom_delete_subscription_$manualB").assertDoesNotExist()
        screenshot("07-subscription-management")
        click("moskom_delete_subscription_$manualA")
        scenario.recreate();scenario.onActivity{model=ViewModelProvider(it)[MainViewModel::class.java]};waitReady()
        compose.onNodeWithTag("moskom_confirm_subscription_delete").assertExists()
        click("moskom_confirm_subscription_delete");waitReady()
        compose.waitUntil(30_000){!model.uiState.value.isRunning}
        assertTrue(model.moskom().state.value.manualSubscriptions.isEmpty())
        runBlocking(Dispatchers.IO){assertNull(MmkvManager.decodeSubscription(manualA));aServers.forEach{assertNull(MmkvManager.decodeServerConfig(it))}}
        compose.onNodeWithTag("moskom_manual_subscriptions_empty").assertExists()
        closeSheet();scenario.recreate();scenario.onActivity{model=ViewModelProvider(it)[MainViewModel::class.java]};waitReady()
        assertTrue(model.moskom().state.value.manualSubscriptions.isEmpty())
        assertEquals("Manual-key",model.moskom().state.value.groups.single().servers.single().name)
        // Empty legacy groups can lack a server index and must still be removable.
        val emptyGroup="moskom-manual-empty"
        runBlocking(Dispatchers.IO){MmkvManager.encodeSubscription(emptyGroup,SubscriptionItem(remarks="Empty manual",autoUpdate=false))}
        dispatch(MoskomAction.Group(emptyGroup))
        assertTrue(model.moskom().state.value.groups.first{it.id==emptyGroup}.servers.isEmpty())
        click("moskom_menu");compose.onNodeWithText(text(R.string.moskom_manage_subscriptions)).performClick()
        click("moskom_delete_subscription_$emptyGroup");click("moskom_confirm_subscription_delete");waitReady()
        assertTrue(model.moskom().state.value.manualSubscriptions.isEmpty())
        runBlocking(Dispatchers.IO){assertNull(MmkvManager.decodeSubscription(emptyGroup))}
        closeSheet()
        dispatch(MoskomAction.DeleteSubscription("missing-group"))
        assertEquals(R.string.moskom_subscription_not_removable,model.moskom().state.value.error)
        assertEquals("Manual-key",model.moskom().state.value.groups.single().servers.single().name)
        scenario.close()
    }
}
